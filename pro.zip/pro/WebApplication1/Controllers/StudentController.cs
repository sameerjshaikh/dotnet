﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class StudentController : Controller
    {
        // GET: Student
        public ViewResult All()
        {
            var com = new WebApplication1.Models.StuDataRepository();
            var table = com.GetAllStudents();

            return View(table);
            
        }

        public ViewResult Find()
        {
            var stu= new Student
            {
                stuId = 121,
                stuName = "sameer",
                stuAddress = "Pune"

            };
            return View(stu);
        }
    }
}