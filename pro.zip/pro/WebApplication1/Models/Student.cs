﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MvcDalLib;
using System.Data;

namespace WebApplication1.Models
{
    public class Student
    {

        public int stuId { get; set; }
        public string stuName { get; set; }
        public string stuAddress { get; set; }

    }

    class StuDataRepository
    {
        public List<Student> GetAllStudents()
        {
            var com = new DaoComponent();

            var table = com.GetAllRecords();

            List<Student> list = new List<Student>();

            foreach(DataRow row in table.Rows)
            {
                var stu = new Student
                {
                    stuId = Convert.ToInt32(row[0]),
                    stuName = row[1].ToString(),
                    stuAddress = row[2].ToString()

                };
                list.Add(stu);
            }
            return list;

        }

    }

}